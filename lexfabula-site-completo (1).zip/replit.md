# LEXFÁBULA - Direito, Imaginário e Contos

## Overview
Educational website for the DICONT (Direito, Imaginário e Contos) study group at Faculdade Liber in Porangatu-GO. The site analyzes fairy tales through the lens of Brazilian Criminal Law (Código Penal Brasileiro).

## Current State
- Full-stack application with React frontend and Express backend
- PostgreSQL database with fairy tales content and quiz questions
- Three fairy tale analyses: Cinderela, Chapeuzinho Vermelho, Três Porquinhos
- Interactive quiz with 6 questions covering criminal law concepts from fairy tales
- Each tale has 3-tab system: Análise Penal, Tipificação, Jurisprudência
- 5 tipificações penais and 5 jurisprudências (STJ/STF) per tale

## Architecture
- Frontend: React + Tailwind CSS + shadcn/ui components + Framer Motion
- Backend: Express.js with TypeScript
- Database: PostgreSQL with Drizzle ORM
- Theme: Academic navy blue + gold color scheme

## Key Files
- `client/src/pages/home.tsx` - Main page with hero, tale cards, quiz, about sections
- `server/routes.ts` - API routes for tales and quiz
- `server/storage.ts` - Database storage layer
- `server/seed.ts` - Seed data with fairy tale content
- `shared/schema.ts` - Database schema (fairyTales, quizQuestions, users)

## API Routes
- GET `/api/tales` - All fairy tales ordered by position
- GET `/api/tales/:slug` - Single tale by slug
- GET `/api/quiz` - All quiz questions

## Design Tokens
- Primary: Deep navy blue (hsl 220 55% 28%)
- Secondary/Accent: Gold (hsl 38 85% 55%)
- Fonts: Playfair Display (headings), Lora (body), Montserrat (UI elements)
