import { useState, useEffect, useCallback, useRef } from "react";
import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { motion, AnimatePresence } from "framer-motion";
import { Volume2, BookOpen, Scale, Gavel } from "lucide-react";
import NotFound from "@/pages/not-found";
import Home from "@/pages/home";
import mascotImg from "@assets/image_1770954699735.png";
import castleImg from "@assets/image_1771114115591.png";
import audio01 from "@assets/audio_01_1770954884825.ogg";
import audio02 from "@assets/WhatsApp_Ptt_2026-02-13_at_audio_02_1770954893324.ogg";
import audio03 from "@assets/WhatsApp_Ptt_2026-02-13_at_03_1770954901157.ogg";
import audio04 from "@assets/aula014_1770954907631.ogg";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route component={NotFound} />
    </Switch>
  );
}

const audioButtons = [
  { src: audio01, label: "Áudio 1", icon: Volume2, color: "hsl(38,85%,55%)" },
  { src: audio02, label: "Áudio 2", icon: BookOpen, color: "hsl(220,55%,50%)" },
  { src: audio03, label: "Áudio 3", icon: Scale, color: "hsl(150,60%,40%)" },
  { src: audio04, label: "Áudio 4", icon: Gavel, color: "hsl(0,65%,50%)" },
];

function AudioButton3D({ src, label, icon: Icon, color, index }: {
  src: string; label: string; icon: typeof Volume2; color: string; index: number;
}) {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [playing, setPlaying] = useState(false);

  const handleClick = () => {
    if (audioRef.current) {
      if (playing) {
        audioRef.current.pause();
        audioRef.current.currentTime = 0;
        setPlaying(false);
      } else {
        audioRef.current.play().catch(() => {});
        setPlaying(true);
      }
    }
  };

  useEffect(() => {
    const audio = new Audio(src);
    audioRef.current = audio;
    audio.addEventListener("ended", () => setPlaying(false));
    return () => {
      audio.pause();
      audio.removeEventListener("ended", () => setPlaying(false));
    };
  }, [src]);

  return (
    <motion.button
      className="relative group cursor-pointer border-none bg-transparent p-0"
      onClick={handleClick}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.15, duration: 0.4 }}
      whileTap={{ scale: 0.92 }}
      data-testid={`intro-audio-btn-${index}`}
    >
      <div
        className="absolute inset-0 rounded-md translate-y-[4px]"
        style={{ backgroundColor: color, filter: "brightness(0.5)" }}
      />
      <div
        className="relative rounded-md px-4 py-3 flex flex-col items-center gap-1.5 transition-transform duration-100 active:translate-y-[3px]"
        style={{
          backgroundColor: color,
          boxShadow: playing
            ? `0 0 16px ${color}, 0 0 30px ${color}40`
            : `0 2px 8px ${color}30`,
        }}
      >
        <div className="flex items-center gap-2">
          <Icon className="w-4 h-4 text-white" />
          {playing && (
            <motion.div
              className="flex items-end gap-[2px] h-4"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
            >
              {[0, 1, 2].map((i) => (
                <motion.div
                  key={i}
                  className="w-[3px] bg-white rounded-full"
                  animate={{ height: ["4px", "14px", "6px", "12px", "4px"] }}
                  transition={{ duration: 0.8, repeat: Infinity, delay: i * 0.15 }}
                />
              ))}
            </motion.div>
          )}
        </div>
        <span
          className="text-[10px] font-semibold text-white/90 tracking-wide uppercase"
          style={{ fontFamily: "'Montserrat', sans-serif" }}
        >
          {label}
        </span>
      </div>
    </motion.button>
  );
}

function FireworkParticle({ x, y, color, delay }: { x: number; y: number; color: string; delay: number }) {
  const angle = Math.random() * Math.PI * 2;
  const distance = Math.random() * 120 + 40;
  const endX = Math.cos(angle) * distance;
  const endY = Math.sin(angle) * distance;
  const size = Math.random() * 4 + 2;

  return (
    <motion.div
      className="absolute rounded-full"
      style={{
        left: `${x}%`,
        top: `${y}%`,
        width: size,
        height: size,
        backgroundColor: color,
        boxShadow: `0 0 ${size * 2}px ${color}`,
      }}
      initial={{ opacity: 0, x: 0, y: 0, scale: 0 }}
      animate={{
        opacity: [0, 1, 1, 0],
        x: [0, endX * 0.3, endX * 0.7, endX],
        y: [0, endY * 0.3, endY * 0.7, endY + 20],
        scale: [0, 1.5, 1, 0],
      }}
      transition={{
        duration: 1.8,
        delay,
        repeat: Infinity,
        repeatDelay: Math.random() * 6 + 3,
        ease: "easeOut",
      }}
    />
  );
}

function FireworkBurst({ x, y, delay }: { x: number; y: number; delay: number }) {
  const colors = [
    "#FFD700", "#FF6B6B", "#4ECDC4", "#FF69B4", "#87CEEB",
    "#FFA500", "#FF4500", "#FFE4B5", "#F0E68C", "#DDA0DD",
  ];
  return (
    <>
      {[...Array(12)].map((_, i) => (
        <FireworkParticle
          key={i}
          x={x}
          y={y}
          color={colors[i % colors.length]}
          delay={delay + i * 0.03}
        />
      ))}
    </>
  );
}

function SparkleTrail({ delay }: { delay: number }) {
  const startX = Math.random() * 80 + 10;
  return (
    <motion.div
      className="absolute w-1 h-1 rounded-full bg-[hsl(38,85%,70%)]"
      style={{
        left: `${startX}%`,
        bottom: "60%",
        boxShadow: "0 0 6px hsl(38,85%,70%), 0 0 12px hsl(38,85%,55%)",
      }}
      initial={{ opacity: 0, y: 0 }}
      animate={{
        opacity: [0, 1, 0.8, 0],
        y: [0, -150, -280, -350],
        x: [0, (Math.random() - 0.5) * 40, (Math.random() - 0.5) * 60],
      }}
      transition={{
        duration: 2,
        delay,
        repeat: Infinity,
        repeatDelay: Math.random() * 4 + 2,
        ease: "easeOut",
      }}
    />
  );
}

function IntroScreen({ onFinish }: { onFinish: () => void }) {
  const [phase, setPhase] = useState(0);
  const [mousePos, setMousePos] = useState({ x: 50, y: 50 });

  useEffect(() => {
    const timers = [
      setTimeout(() => setPhase(1), 300),
      setTimeout(() => setPhase(2), 1500),
      setTimeout(() => setPhase(3), 3000),
      setTimeout(() => setPhase(4), 5000),
      setTimeout(() => setPhase(5), 8000),
      setTimeout(() => setPhase(6), 13000),
      setTimeout(() => onFinish(), 20000),
    ];
    return () => timers.forEach(clearTimeout);
  }, [onFinish]);

  const handleMouseMove = useCallback((e: React.MouseEvent) => {
    const rect = e.currentTarget.getBoundingClientRect();
    setMousePos({
      x: ((e.clientX - rect.left) / rect.width) * 100,
      y: ((e.clientY - rect.top) / rect.height) * 100,
    });
  }, []);

  return (
    <motion.div
      className="fixed inset-0 z-[9999] flex flex-col items-center justify-center overflow-hidden cursor-crosshair"
      exit={{ opacity: 0, scale: 1.1 }}
      transition={{ duration: 1.2 }}
      onMouseMove={handleMouseMove}
    >
      <motion.div
        className="absolute inset-0"
        initial={{ scale: 1.2 }}
        animate={{ scale: 1 }}
        transition={{ duration: 20, ease: "linear" }}
      >
        <img
          src={castleImg}
          alt=""
          className="w-full h-full object-cover"
          style={{ filter: "brightness(0.7) saturate(1.2)" }}
        />
      </motion.div>

      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-black/50" />

      <motion.div
        className="absolute inset-0 pointer-events-none"
        style={{
          background: `radial-gradient(circle 200px at ${mousePos.x}% ${mousePos.y}%, rgba(255,215,0,0.15), transparent)`,
        }}
      />

      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <FireworkBurst x={15} y={15} delay={0.5} />
        <FireworkBurst x={85} y={20} delay={2} />
        <FireworkBurst x={50} y={10} delay={3.5} />
        <FireworkBurst x={25} y={25} delay={5} />
        <FireworkBurst x={75} y={15} delay={6.5} />
        <FireworkBurst x={40} y={20} delay={8} />
        <FireworkBurst x={60} y={12} delay={9.5} />
        <FireworkBurst x={30} y={18} delay={11} />
        <FireworkBurst x={70} y={22} delay={12.5} />
        <FireworkBurst x={50} y={8} delay={14} />
        <FireworkBurst x={20} y={30} delay={15.5} />
        <FireworkBurst x={80} y={10} delay={17} />

        {[...Array(15)].map((_, i) => (
          <SparkleTrail key={i} delay={i * 0.8} />
        ))}

        {[...Array(30)].map((_, i) => (
          <motion.div
            key={`star-${i}`}
            className="absolute rounded-full bg-white"
            style={{
              width: Math.random() * 3 + 1,
              height: Math.random() * 3 + 1,
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 50}%`,
            }}
            animate={{
              opacity: [0, 0.8, 0],
              scale: [0, 1, 0],
            }}
            transition={{
              duration: Math.random() * 2 + 1,
              repeat: Infinity,
              delay: Math.random() * 8,
            }}
          />
        ))}
      </div>

      <motion.div
        className="absolute top-0 left-0 right-0 h-1.5 bg-white/10 origin-left"
        initial={{ scaleX: 0 }}
        animate={{ scaleX: 1 }}
        transition={{ duration: 20, ease: "linear" }}
      >
        <motion.div
          className="h-full"
          style={{ background: "linear-gradient(90deg, hsl(38,85%,55%), hsl(0,65%,55%), hsl(280,70%,60%), hsl(38,85%,55%))", backgroundSize: "200% 100%", transformOrigin: "left" }}
          initial={{ scaleX: 0 }}
          animate={{ scaleX: 1 }}
          transition={{ duration: 20, ease: "linear" }}
        />
      </motion.div>

      <div className="relative flex flex-col items-center gap-5 px-4 z-10">
        <motion.div
          initial={{ scale: 0, rotate: -20 }}
          animate={phase >= 1 ? { scale: 1, rotate: 0 } : { scale: 0, rotate: -20 }}
          transition={{ type: "spring", stiffness: 200, damping: 15 }}
          className="relative"
        >
          <motion.div
            className="absolute -inset-6 rounded-full"
            style={{ background: "radial-gradient(circle, rgba(255,215,0,0.3), transparent)" }}
            animate={{ scale: [1, 1.4, 1], opacity: [0.4, 0.8, 0.4] }}
            transition={{ duration: 2.5, repeat: Infinity }}
          />
          <motion.div
            className="absolute -inset-8 rounded-full"
            style={{ background: "radial-gradient(circle, rgba(255,100,100,0.15), transparent)" }}
            animate={{ scale: [1.2, 1, 1.2], opacity: [0.2, 0.5, 0.2] }}
            transition={{ duration: 3, repeat: Infinity, delay: 0.5 }}
          />
          <motion.img
            src={mascotImg}
            alt="Mascote LEXFÁBULA"
            className="w-36 h-36 md:w-48 md:h-48 object-contain relative z-10 drop-shadow-[0_0_30px_rgba(255,215,0,0.5)]"
            animate={phase >= 1 ? { y: [0, -10, 0], rotate: [0, 2, -2, 0] } : {}}
            transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
            data-testid="intro-mascot"
          />
        </motion.div>

        <motion.h1
          className="text-4xl md:text-6xl lg:text-7xl font-bold tracking-tight text-white drop-shadow-[0_0_30px_rgba(255,215,0,0.4)]"
          style={{ fontFamily: "'Playfair Display', serif" }}
          initial={{ opacity: 0, y: 30 }}
          animate={phase >= 2 ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
          transition={{ duration: 0.8 }}
          data-testid="intro-title"
        >
          <motion.span
            className="text-[hsl(38,85%,65%)]"
            animate={phase >= 2 ? { textShadow: ["0 0 20px rgba(255,215,0,0.5)", "0 0 40px rgba(255,215,0,0.8)", "0 0 20px rgba(255,215,0,0.5)"] } : {}}
            transition={{ duration: 2, repeat: Infinity }}
          >
            LEX
          </motion.span>FÁBULA
        </motion.h1>

        <AnimatePresence mode="wait">
          {phase >= 3 && phase < 6 && (
            <motion.p
              key="subtitle1"
              className="text-base md:text-lg text-white/80 italic text-center max-w-md drop-shadow-lg"
              style={{ fontFamily: "'Lora', serif" }}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.6 }}
              data-testid="intro-subtitle-1"
            >
              Do latim: Lex (Lei) + Fabula (Narrativa/Conto)
            </motion.p>
          )}
          {phase >= 6 && (
            <motion.div
              key="educacao"
              className="text-center"
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 1, type: "spring", stiffness: 100 }}
              data-testid="intro-educacao"
            >
              <motion.p
                className="text-2xl md:text-4xl lg:text-5xl font-bold text-white tracking-wide"
                style={{ fontFamily: "'Playfair Display', serif" }}
                animate={{
                  textShadow: [
                    "0 0 20px rgba(255,215,0,0.3)",
                    "0 0 60px rgba(255,215,0,0.6)",
                    "0 0 20px rgba(255,215,0,0.3)",
                  ],
                }}
                transition={{ duration: 2, repeat: Infinity }}
              >
                <motion.span
                  className="text-[hsl(38,85%,65%)]"
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.3, duration: 0.6 }}
                >
                  A educação{" "}
                </motion.span>
                <motion.span
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.8, duration: 0.6 }}
                >
                  salva vidas
                </motion.span>
              </motion.p>
              <motion.div
                className="mt-4 flex items-center justify-center gap-3"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 1.5, duration: 0.6 }}
              >
                <motion.div
                  className="h-px bg-[hsl(38,85%,55%)]"
                  initial={{ width: 0 }}
                  animate={{ width: 60 }}
                  transition={{ delay: 1.8, duration: 0.8 }}
                />
                <span className="text-xs text-[hsl(38,85%,65%)] tracking-[0.3em] uppercase" style={{ fontFamily: "'Montserrat', sans-serif" }}>
                  DICONT
                </span>
                <motion.div
                  className="h-px bg-[hsl(38,85%,55%)]"
                  initial={{ width: 0 }}
                  animate={{ width: 60 }}
                  transition={{ delay: 1.8, duration: 0.8 }}
                />
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        <motion.div
          className="flex items-center gap-3 mt-1"
          initial={{ opacity: 0 }}
          animate={phase >= 4 && phase < 6 ? { opacity: 1 } : { opacity: 0 }}
          transition={{ duration: 0.6 }}
        >
          <div className="h-px w-12 bg-[hsl(38,85%,55%)]/40" />
          <span className="text-xs text-[hsl(38,85%,65%)] tracking-widest uppercase" style={{ fontFamily: "'Montserrat', sans-serif" }}>
            DICONT
          </span>
          <div className="h-px w-12 bg-[hsl(38,85%,55%)]/40" />
        </motion.div>

        <motion.p
          className="text-xs text-white/50 text-center"
          style={{ fontFamily: "'Montserrat', sans-serif" }}
          initial={{ opacity: 0 }}
          animate={phase >= 4 && phase < 6 ? { opacity: 1 } : { opacity: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
          data-testid="intro-institution"
        >
          Direito, Imaginário e Contos | Faculdade Liber - Porangatu/GO
        </motion.p>

        <motion.p
          className="text-sm text-[hsl(38,85%,65%)] font-medium tracking-wide"
          style={{ fontFamily: "'Montserrat', sans-serif" }}
          initial={{ opacity: 0 }}
          animate={phase >= 5 && phase < 6 ? { opacity: 1 } : { opacity: 0 }}
          transition={{ duration: 0.6 }}
        >
          Gestor Professor Sandro Dias
        </motion.p>

        <motion.div
          className="flex flex-wrap items-center justify-center gap-3 mt-2"
          initial={{ opacity: 0 }}
          animate={phase >= 3 && phase < 6 ? { opacity: 1 } : { opacity: 0 }}
          transition={{ duration: 0.6 }}
          data-testid="intro-audio-buttons"
        >
          {audioButtons.map((btn, i) => (
            <AudioButton3D key={i} {...btn} index={i} />
          ))}
        </motion.div>
      </div>

      <motion.button
        className="absolute bottom-8 text-xs text-white/40 cursor-pointer bg-transparent border-none z-20 px-4 py-2 rounded-full backdrop-blur-sm bg-white/5"
        style={{ fontFamily: "'Montserrat', sans-serif" }}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 2 }}
        onClick={onFinish}
        whileHover={{ backgroundColor: "rgba(255,255,255,0.15)", color: "rgba(255,255,255,0.8)" }}
        data-testid="intro-skip"
      >
        Pular introdução
      </motion.button>
    </motion.div>
  );
}

function App() {
  const [showIntro, setShowIntro] = useState(true);
  const handleFinish = useCallback(() => setShowIntro(false), []);

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <AnimatePresence mode="wait">
          {showIntro && <IntroScreen key="intro" onFinish={handleFinish} />}
        </AnimatePresence>
        {!showIntro && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8 }}
          >
            <Router />
          </motion.div>
        )}
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
