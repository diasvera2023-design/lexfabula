import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { BookOpen, Scale, GraduationCap, Users, ScrollText, Gavel, ChevronRight, Sparkles, Shield, BookMarked, ArrowRight, CheckCircle2, XCircle, HelpCircle, FileText, Landmark } from "lucide-react";
import type { FairyTale, QuizQuestion } from "@shared/schema";
import cinderelaPng from "@assets/image_1770950847929.png";
import chapeuzinhoPng from "@assets/image_1770950960533.png";
import porquinhosPng from "@assets/image_1770951074570.png";
import heroChapeuzinho from "@assets/image_1770956126939.png";
import heroCinderela from "@assets/image_1770956749634.png";
import heroPorquinhos from "@assets/image_1770956807098.png";

const taleImages: Record<string, string> = {
  cinderela: cinderelaPng,
  chapeuzinho: chapeuzinhoPng,
  "tres-porquinhos": porquinhosPng,
};

function HeroSection() {
  return (
    <section className="relative overflow-hidden bg-gradient-to-br from-[hsl(220,55%,18%)] via-[hsl(220,45%,22%)] to-[hsl(220,35%,28%)] text-white min-h-[70vh]">
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-10 left-10 w-64 h-64 rounded-full bg-[hsl(38,85%,55%)] blur-[100px]" />
        <div className="absolute bottom-10 right-10 w-96 h-96 rounded-full bg-[hsl(220,55%,45%)] blur-[120px]" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-72 h-72 rounded-full bg-[hsl(38,85%,55%)] blur-[80px]" />
      </div>

      <div className="absolute inset-0 pointer-events-none flex">
        <motion.div
          className="relative flex-1 h-full overflow-hidden"
          initial={{ opacity: 0, x: -30 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 1.2, delay: 0.3 }}
        >
          <img
            src={heroChapeuzinho}
            alt=""
            className="w-full h-full object-cover drop-shadow-[0_0_20px_rgba(200,160,80,0.25)]"
            style={{ opacity: 0.4, filter: "brightness(1.1) saturate(0.55)" }}
          />
        </motion.div>

        <motion.div
          className="relative flex-1 h-full overflow-hidden"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1.2, delay: 0.5 }}
        >
          <img
            src={heroCinderela}
            alt=""
            className="w-full h-full object-cover object-[50%_15%] drop-shadow-[0_0_25px_rgba(100,140,220,0.3)]"
            style={{ opacity: 0.45, filter: "brightness(1.15) saturate(0.5)" }}
          />
        </motion.div>

        <motion.div
          className="relative flex-1 h-full overflow-hidden"
          initial={{ opacity: 0, x: 30 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 1.2, delay: 0.7 }}
        >
          <img
            src={heroPorquinhos}
            alt=""
            className="w-full h-full object-cover object-[65%_15%] drop-shadow-[0_0_20px_rgba(200,160,80,0.25)]"
            style={{ opacity: 0.4, filter: "brightness(1.1) saturate(0.55)" }}
          />
        </motion.div>

        <div className="absolute inset-0 bg-gradient-to-b from-[hsl(220,55%,18%)]/70 via-[hsl(220,55%,18%)]/40 to-[hsl(220,55%,18%)]/90" />
        <div className="absolute inset-0 bg-gradient-to-r from-[hsl(220,55%,18%)]/50 via-transparent to-[hsl(220,55%,18%)]/50" />
      </div>

      <div className="relative z-10 max-w-6xl mx-auto px-4 py-16 md:py-24">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7 }}
          className="text-center"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 backdrop-blur-sm mb-6">
            <Scale className="w-4 h-4 text-[hsl(38,85%,65%)]" />
            <span className="text-sm font-medium tracking-wide text-white/90" style={{ fontFamily: "'Montserrat', sans-serif" }}>
              Faculdade Liber - Porangatu/GO
            </span>
          </div>

          <h1
            className="text-4xl md:text-6xl lg:text-7xl font-bold mb-4 tracking-tight"
            style={{ fontFamily: "'Playfair Display', serif" }}
          >
            <span className="text-[hsl(38,85%,65%)]">LEX</span>FÁBULA
          </h1>

          <p
            className="text-lg md:text-xl text-white/70 italic mb-2"
            style={{ fontFamily: "'Lora', serif" }}
          >
            Do latim: Lex (Lei) + Fabula (Narrativa/Conto)
          </p>

          <p
            className="text-sm md:text-base text-[hsl(38,85%,65%)] font-medium mb-4 tracking-wide"
            style={{ fontFamily: "'Montserrat', sans-serif" }}
          >
            Gestor Professor Sandro Dias
          </p>

          <div className="flex items-center justify-center gap-2 mb-8">
            <Badge variant="outline" className="border-[hsl(38,85%,55%)]/40 text-[hsl(38,85%,65%)] bg-[hsl(38,85%,55%)]/10 no-default-hover-elevate no-default-active-elevate">
              <BookOpen className="w-3 h-3 mr-1" />
              DICONT
            </Badge>
            <span className="text-white/40">|</span>
            <span className="text-sm text-white/60" style={{ fontFamily: "'Montserrat', sans-serif" }}>
              Direito, Imaginário e Contos
            </span>
          </div>

          <p
            className="max-w-2xl mx-auto text-base md:text-lg text-white/80 mb-10 leading-relaxed"
            style={{ fontFamily: "'Lora', serif" }}
          >
            Estudo interdisciplinar entre o Direito Penal, a Criminologia e a Literatura Infantojuvenil.
            Desconstruindo a "Justiça dos Contos" para entender como conceitos como culpa, retribuição,
            dolo e legítima defesa moldam a percepção social do sistema penal.
          </p>

          <div className="flex flex-wrap items-center justify-center gap-4">
            <a href="#contos" data-testid="link-explore-tales">
              <Button
                data-testid="button-explore-tales"
                className="bg-[hsl(38,85%,55%)] text-[hsl(220,55%,12%)] border-[hsl(38,85%,45%)] font-semibold px-6"
                style={{ fontFamily: "'Montserrat', sans-serif" }}
              >
                <BookMarked className="w-4 h-4 mr-2" />
                Explorar Contos
              </Button>
            </a>
            <a href="#quiz" data-testid="link-quiz">
              <Button
                data-testid="button-quiz"
                variant="outline"
                className="border-white/30 text-white bg-white/5 backdrop-blur-sm font-semibold px-6"
                style={{ fontFamily: "'Montserrat', sans-serif" }}
              >
                <Gavel className="w-4 h-4 mr-2" />
                Quiz Jurídico
              </Button>
            </a>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.3 }}
          className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-16"
        >
          {[
            { icon: Scale, title: "Direito Penal", desc: "Análise de tipos penais nos contos clássicos" },
            { icon: BookOpen, title: "Literatura", desc: "Contos de fadas sob a ótica jurídica" },
            { icon: Shield, title: "Criminologia", desc: "Percepção social do sistema penal" },
          ].map((item, i) => (
            <div
              key={i}
              className="flex items-start gap-3 p-4 rounded-md bg-white/5 backdrop-blur-sm border border-white/10"
            >
              <div className="p-2 rounded-md bg-[hsl(38,85%,55%)]/20">
                <item.icon className="w-5 h-5 text-[hsl(38,85%,65%)]" />
              </div>
              <div>
                <h3 className="font-semibold text-white text-sm" style={{ fontFamily: "'Montserrat', sans-serif" }}>{item.title}</h3>
                <p className="text-xs text-white/60" style={{ fontFamily: "'Lora', serif" }}>{item.desc}</p>
              </div>
            </div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}

function TaleCard({ tale, index }: { tale: FairyTale; index: number }) {
  const [expanded, setExpanded] = useState(false);
  const imageUrl = taleImages[tale.slug] || tale.imageUrl || "";

  const crimes = tale.crimes || [];
  const articles = tale.articles || [];
  const penalties = tale.penalties || [];
  const tipificacao = tale.tipificacao || [];
  const jurisprudencia = tale.jurisprudencia || [];
  const fundamentacao = tale.fundamentacao || [];

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay: index * 0.15 }}
    >
      <Card className="overflow-visible group">
        <div className="flex flex-col lg:flex-row">
          {imageUrl && (
            <div className="lg:w-72 flex-shrink-0 p-4 flex items-center justify-center">
              <div className="relative w-48 h-48 lg:w-56 lg:h-56">
                <img
                  src={imageUrl}
                  alt={tale.title}
                  className="w-full h-full object-contain rounded-md"
                  data-testid={`img-tale-${tale.slug}`}
                />
              </div>
            </div>
          )}

          <div className="flex-1 p-4 lg:p-6">
            <div className="flex flex-wrap items-center gap-2 mb-3">
              <Badge className="bg-[hsl(220,55%,28%)] text-white no-default-hover-elevate no-default-active-elevate">
                <Gavel className="w-3 h-3 mr-1" />
                Análise Penal
              </Badge>
              {crimes.slice(0, 2).map((crime, i) => (
                <Badge key={i} variant="outline" className="text-xs">
                  {crime}
                </Badge>
              ))}
            </div>

            <h3
              className="text-xl md:text-2xl font-bold mb-2 text-foreground"
              style={{ fontFamily: "'Playfair Display', serif" }}
              data-testid={`text-title-${tale.slug}`}
            >
              {tale.title}
            </h3>

            <p
              className="text-sm text-muted-foreground leading-relaxed mb-4"
              style={{ fontFamily: "'Lora', serif" }}
            >
              {tale.summary}
            </p>

            <Button
              data-testid={`button-expand-${tale.slug}`}
              variant="outline"
              onClick={() => setExpanded(!expanded)}
              style={{ fontFamily: "'Montserrat', sans-serif" }}
            >
              {expanded ? "Recolher" : "Ver Análise Completa"}
              <ChevronRight className={`w-4 h-4 ml-1 transition-transform ${expanded ? "rotate-90" : ""}`} />
            </Button>

            <AnimatePresence>
              {expanded && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: "auto", opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.3 }}
                  className="overflow-hidden"
                >
                  <div className="mt-4 relative">
                    <svg className="w-full h-4 -mb-px" viewBox="0 0 1200 20" preserveAspectRatio="none">
                      <path d="M0,10 C50,0 100,20 150,10 C200,0 250,20 300,10 C350,0 400,20 450,10 C500,0 550,20 600,10 C650,0 700,20 750,10 C800,0 850,20 900,10 C950,0 1000,20 1050,10 C1100,0 1150,20 1200,10" fill="none" stroke="hsl(38,85%,55%)" strokeWidth="2" strokeOpacity="0.5" />
                    </svg>
                    <div className="border-x border-[hsl(38,85%,55%)]/20 px-1">
                    <Tabs defaultValue="analise" className="w-full">
                      <TabsList className="w-full justify-start flex-wrap h-auto gap-1 bg-muted/50 p-1">
                        <TabsTrigger value="analise" className="text-xs" style={{ fontFamily: "'Montserrat', sans-serif" }} data-testid={`tab-analise-${tale.slug}`}>
                          <Scale className="w-3 h-3 mr-1" />
                          Análise Penal
                        </TabsTrigger>
                        <TabsTrigger value="tipificacao" className="text-xs" style={{ fontFamily: "'Montserrat', sans-serif" }} data-testid={`tab-tipificacao-${tale.slug}`}>
                          <FileText className="w-3 h-3 mr-1" />
                          Tipificação
                        </TabsTrigger>
                        <TabsTrigger value="jurisprudencia" className="text-xs" style={{ fontFamily: "'Montserrat', sans-serif" }} data-testid={`tab-jurisprudencia-${tale.slug}`}>
                          <Landmark className="w-3 h-3 mr-1" />
                          Jurisprudência
                        </TabsTrigger>
                        <TabsTrigger value="fundamentacao" className="text-xs" style={{ fontFamily: "'Montserrat', sans-serif" }} data-testid={`tab-fundamentacao-${tale.slug}`}>
                          <BookMarked className="w-3 h-3 mr-1" />
                          Fundamentação
                        </TabsTrigger>
                      </TabsList>

                      <TabsContent value="analise" className="mt-4 space-y-4">
                        <div
                          className="prose prose-sm max-w-none text-foreground dark:text-foreground"
                          style={{ fontFamily: "'Lora', serif" }}
                          dangerouslySetInnerHTML={{ __html: tale.content.replace(/\n/g, "<br/>") }}
                        />

                        {articles.length > 0 && (
                          <div className="mt-4">
                            <h4 className="font-semibold text-sm mb-2 flex items-center gap-2" style={{ fontFamily: "'Montserrat', sans-serif" }}>
                              <ScrollText className="w-4 h-4 text-[hsl(38,85%,55%)]" />
                              Artigos do Código Penal
                            </h4>
                            <div className="flex flex-wrap gap-2">
                              {articles.map((article, i) => (
                                <Badge key={i} className="bg-[hsl(38,85%,55%)]/15 text-[hsl(38,85%,40%)] dark:text-[hsl(38,85%,65%)] border border-[hsl(38,85%,55%)]/30 no-default-hover-elevate no-default-active-elevate">
                                  {article}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        )}

                        {penalties.length > 0 && (
                          <div className="mt-4">
                            <h4 className="font-semibold text-sm mb-2 flex items-center gap-2" style={{ fontFamily: "'Montserrat', sans-serif" }}>
                              <Shield className="w-4 h-4 text-[hsl(0,65%,45%)]" />
                              Penas Previstas
                            </h4>
                            <div className="space-y-1">
                              {penalties.map((penalty, i) => (
                                <div key={i} className="text-xs text-muted-foreground flex items-start gap-2 p-2 rounded-md bg-muted/50">
                                  <Gavel className="w-3 h-3 mt-0.5 flex-shrink-0 text-[hsl(0,65%,45%)]" />
                                  <span style={{ fontFamily: "'Lora', serif" }}>{penalty}</span>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                      </TabsContent>

                      <TabsContent value="tipificacao" className="mt-4 space-y-3" data-testid={`content-tipificacao-${tale.slug}`}>
                        {tipificacao.length > 0 ? (
                          <Accordion type="single" collapsible className="w-full">
                            {tipificacao.map((tip, i) => {
                              const titleMatch = tip.match(/^([^—]+)/);
                              const title = titleMatch ? titleMatch[1].trim() : `Tipo Penal ${i + 1}`;
                              const body = tip.includes("—") ? tip.substring(tip.indexOf("—") + 1).trim() : tip;
                              const elements = body.split(/(?=Tipo objetivo:|Tipo subjetivo:|Sujeito ativo:|Sujeito passivo:|Bem jurídico tutelado:|Consumação:|Qualificadora:|Iter criminis:|Meio executório:|Classificação:|Elemento normativo:|Observação:|Causa de aumento|Modo de execução:|Ação penal:|Requisitos:|Análise:|Limite:|Efeito:|Conceito:|Objeto material:|Redução de pena:|Meio executório:)/).filter(Boolean);
                              return (
                                <AccordionItem key={i} value={`tip-${i}`}>
                                  <AccordionTrigger
                                    className="text-left text-sm"
                                    style={{ fontFamily: "'Montserrat', sans-serif" }}
                                    data-testid={`accordion-tip-${tale.slug}-${i}`}
                                  >
                                    <div className="flex items-center gap-2">
                                      <FileText className="w-4 h-4 text-[hsl(220,55%,45%)] flex-shrink-0" />
                                      <span>{title}</span>
                                    </div>
                                  </AccordionTrigger>
                                  <AccordionContent>
                                    <div className="space-y-2 pl-6">
                                      {elements.map((el, j) => {
                                        const colonIdx = el.indexOf(":");
                                        if (colonIdx === -1) return (
                                          <p key={j} className="text-sm text-muted-foreground" style={{ fontFamily: "'Lora', serif" }}>{el.trim()}</p>
                                        );
                                        const label = el.substring(0, colonIdx).trim();
                                        const value = el.substring(colonIdx + 1).trim().replace(/\.\s*$/, "");
                                        return (
                                          <div key={j} className="flex flex-col gap-0.5">
                                            <span className="text-xs font-semibold text-[hsl(220,55%,28%)] dark:text-[hsl(220,55%,65%)]" style={{ fontFamily: "'Montserrat', sans-serif" }}>
                                              {label}
                                            </span>
                                            <span className="text-sm text-muted-foreground" style={{ fontFamily: "'Lora', serif" }}>
                                              {value}
                                            </span>
                                          </div>
                                        );
                                      })}
                                    </div>
                                  </AccordionContent>
                                </AccordionItem>
                              );
                            })}
                          </Accordion>
                        ) : (
                          <p className="text-sm text-muted-foreground" style={{ fontFamily: "'Lora', serif" }}>
                            Tipificação penal não disponível para este conto.
                          </p>
                        )}
                      </TabsContent>

                      <TabsContent value="jurisprudencia" className="mt-4 space-y-3" data-testid={`content-jurisprudencia-${tale.slug}`}>
                        {jurisprudencia.length > 0 ? (
                          <div className="space-y-3">
                            {jurisprudencia.map((jur, i) => {
                              const parts = jur.split(" — Relevância: ");
                              const citacao = parts[0] || jur;
                              const relevancia = parts[1] || "";
                              const tribunalMatch = citacao.match(/^(STF|STJ|TJSP|TJMG|TJRJ|TJ\w+)\s*—\s*/);
                              const tribunal = tribunalMatch ? tribunalMatch[1] : "";
                              const restoCitacao = tribunalMatch ? citacao.substring(tribunalMatch[0].length) : citacao;
                              const quoteMatch = restoCitacao.match(/"([^"]+)"/);
                              const caseRef = restoCitacao.replace(/"[^"]*"/, "").replace(/:\s*$/, "").trim();
                              const quote = quoteMatch ? quoteMatch[1] : "";
                              return (
                                <div key={i} className="p-3 rounded-md border border-[hsl(220,55%,28%)]/15 dark:border-[hsl(220,55%,45%)]/15 bg-[hsl(220,55%,28%)]/3 dark:bg-[hsl(220,55%,45%)]/5" data-testid={`jurisprudencia-${tale.slug}-${i}`}>
                                  <div className="flex items-start gap-2 mb-2">
                                    <Landmark className="w-4 h-4 text-[hsl(220,55%,45%)] flex-shrink-0 mt-0.5" />
                                    <div className="flex flex-wrap items-center gap-2">
                                      {tribunal && (
                                        <Badge className="bg-[hsl(220,55%,28%)] text-white text-xs no-default-hover-elevate no-default-active-elevate">
                                          {tribunal}
                                        </Badge>
                                      )}
                                      <span className="text-xs font-semibold text-foreground" style={{ fontFamily: "'Montserrat', sans-serif" }}>
                                        {caseRef}
                                      </span>
                                    </div>
                                  </div>
                                  {quote && (
                                    <blockquote className="border-l-2 border-[hsl(38,85%,55%)] pl-3 my-2 italic text-sm text-muted-foreground" style={{ fontFamily: "'Lora', serif" }}>
                                      &ldquo;{quote}&rdquo;
                                    </blockquote>
                                  )}
                                  {relevancia && (
                                    <div className="mt-2 flex items-start gap-2">
                                      <Badge variant="outline" className="text-xs flex-shrink-0 no-default-hover-elevate no-default-active-elevate">
                                        Relevância
                                      </Badge>
                                      <span className="text-xs text-muted-foreground" style={{ fontFamily: "'Lora', serif" }}>
                                        {relevancia}
                                      </span>
                                    </div>
                                  )}
                                </div>
                              );
                            })}
                          </div>
                        ) : (
                          <p className="text-sm text-muted-foreground" style={{ fontFamily: "'Lora', serif" }}>
                            Jurisprudência não disponível para este conto.
                          </p>
                        )}
                      </TabsContent>

                      <TabsContent value="fundamentacao" className="mt-4 space-y-3" data-testid={`content-fundamentacao-${tale.slug}`}>
                        {fundamentacao.length > 0 ? (
                          <Accordion type="single" collapsible className="w-full">
                            {fundamentacao.map((fund, i) => {
                              const titleMatch = fund.match(/^([^—]+)/);
                              const title = titleMatch ? titleMatch[1].trim() : `Etapa ${i + 1}`;
                              const body = fund.includes("—") ? fund.substring(fund.indexOf("—") + 1).trim() : fund;

                              const sectionIcons = [
                                <ScrollText className="w-4 h-4 text-[hsl(38,85%,55%)] flex-shrink-0" />,
                                <Gavel className="w-4 h-4 text-[hsl(0,65%,45%)] flex-shrink-0" />,
                                <Shield className="w-4 h-4 text-[hsl(220,55%,45%)] flex-shrink-0" />,
                                <Scale className="w-4 h-4 text-[hsl(150,50%,40%)] flex-shrink-0" />,
                                <BookMarked className="w-4 h-4 text-[hsl(38,85%,55%)] flex-shrink-0" />,
                              ];

                              const sectionColors = [
                                "border-[hsl(38,85%,55%)]/30",
                                "border-[hsl(0,65%,45%)]/30",
                                "border-[hsl(220,55%,45%)]/30",
                                "border-[hsl(150,50%,40%)]/30",
                                "border-[hsl(38,85%,55%)]/30",
                              ];

                              const items = body.split(/(?=Fato \d+:|Fato \d+ →|Quanto a|Estado de Necessidade|Legítima Defesa|Estrito Cumprimento|Exercício Regular|Conclusão:|Imputabilidade|Potencial consciência|Exigibilidade|Inexigibilidade|Código Penal|Lei nº|Constituição Federal|Jurisprudência aplicável|Doutrina|Estatuto|Art\. 27|Atipicidade|Excesso|Distinção|§|Chapeuzinho|Lobo Mau:|Mãe de|Porquinhos:|Caçador:|Se agiram)/).filter(Boolean);

                              return (
                                <AccordionItem key={i} value={`fund-${i}`}>
                                  <AccordionTrigger
                                    className="text-left text-sm"
                                    style={{ fontFamily: "'Montserrat', sans-serif" }}
                                    data-testid={`accordion-fund-${tale.slug}-${i}`}
                                  >
                                    <div className="flex items-center gap-2">
                                      {sectionIcons[i] || <BookMarked className="w-4 h-4 text-[hsl(38,85%,55%)] flex-shrink-0" />}
                                      <span>{title}</span>
                                    </div>
                                  </AccordionTrigger>
                                  <AccordionContent>
                                    <div className={`space-y-2 pl-6 border-l-2 ${sectionColors[i] || "border-[hsl(38,85%,55%)]/30"} ml-2`}>
                                      {items.map((item, j) => {
                                        const trimmed = item.trim();
                                        if (!trimmed) return null;

                                        const hasArrow = trimmed.includes("→");
                                        const hasColon = trimmed.includes(":");

                                        if (hasArrow) {
                                          const [ref, ...rest] = trimmed.split("→");
                                          return (
                                            <div key={j} className="p-2 rounded-md bg-muted/50">
                                              <span className="text-xs font-bold text-[hsl(220,55%,28%)] dark:text-[hsl(220,55%,65%)]" style={{ fontFamily: "'Montserrat', sans-serif" }}>
                                                {ref.trim()}
                                              </span>
                                              <span className="text-xs text-muted-foreground" style={{ fontFamily: "'Lora', serif" }}>
                                                {" → "}{rest.join("→").trim()}
                                              </span>
                                            </div>
                                          );
                                        }

                                        if (hasColon) {
                                          const colonIdx = trimmed.indexOf(":");
                                          const label = trimmed.substring(0, colonIdx).trim();
                                          const value = trimmed.substring(colonIdx + 1).trim();
                                          return (
                                            <div key={j} className="p-2 rounded-md bg-muted/50">
                                              <span className="text-xs font-semibold text-[hsl(220,55%,28%)] dark:text-[hsl(220,55%,65%)]" style={{ fontFamily: "'Montserrat', sans-serif" }}>
                                                {label}:
                                              </span>{" "}
                                              <span className="text-xs text-muted-foreground" style={{ fontFamily: "'Lora', serif" }}>
                                                {value}
                                              </span>
                                            </div>
                                          );
                                        }

                                        return (
                                          <p key={j} className="text-xs text-muted-foreground p-2" style={{ fontFamily: "'Lora', serif" }}>
                                            {trimmed}
                                          </p>
                                        );
                                      })}
                                    </div>
                                  </AccordionContent>
                                </AccordionItem>
                              );
                            })}
                          </Accordion>
                        ) : (
                          <p className="text-sm text-muted-foreground" style={{ fontFamily: "'Lora', serif" }}>
                            Fundamentação não disponível para este conto.
                          </p>
                        )}
                      </TabsContent>
                    </Tabs>
                    </div>
                    <svg className="w-full h-4 -mt-px" viewBox="0 0 1200 20" preserveAspectRatio="none">
                      <path d="M0,10 C50,20 100,0 150,10 C200,20 250,0 300,10 C350,20 400,0 450,10 C500,20 550,0 600,10 C650,20 700,0 750,10 C800,20 850,0 900,10 C950,20 1000,0 1050,10 C1100,20 1150,0 1200,10" fill="none" stroke="hsl(38,85%,55%)" strokeWidth="2" strokeOpacity="0.5" />
                    </svg>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </Card>
    </motion.div>
  );
}

function QuizSection({ questions }: { questions: QuizQuestion[] }) {
  const [currentQ, setCurrentQ] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [score, setScore] = useState(0);
  const [finished, setFinished] = useState(false);

  if (questions.length === 0) return null;

  const question = questions[currentQ];

  const handleAnswer = (index: number) => {
    if (selected !== null) return;
    setSelected(index);
    setShowResult(true);
    if (index === question.correctIndex) {
      setScore((s) => s + 1);
    }
  };

  const nextQuestion = () => {
    if (currentQ + 1 >= questions.length) {
      setFinished(true);
    } else {
      setCurrentQ((c) => c + 1);
      setSelected(null);
      setShowResult(false);
    }
  };

  const restartQuiz = () => {
    setCurrentQ(0);
    setSelected(null);
    setShowResult(false);
    setScore(0);
    setFinished(false);
  };

  if (finished) {
    return (
      <Card className="p-6 text-center">
        <div className="p-4 rounded-full bg-[hsl(38,85%,55%)]/10 inline-flex mb-4">
          <GraduationCap className="w-10 h-10 text-[hsl(38,85%,55%)]" />
        </div>
        <h3 className="text-2xl font-bold mb-2" style={{ fontFamily: "'Playfair Display', serif" }}>
          Quiz Concluído!
        </h3>
        <p className="text-lg text-muted-foreground mb-4" style={{ fontFamily: "'Lora', serif" }}>
          Você acertou <span className="font-bold text-foreground">{score}</span> de{" "}
          <span className="font-bold text-foreground">{questions.length}</span> questões
        </p>
        <div className="w-full max-w-xs mx-auto h-3 rounded-full bg-muted overflow-hidden mb-6">
          <div
            className="h-full rounded-full bg-[hsl(38,85%,55%)] transition-all duration-500"
            style={{ width: `${(score / questions.length) * 100}%` }}
          />
        </div>
        <Button
          data-testid="button-restart-quiz"
          onClick={restartQuiz}
          className="bg-[hsl(220,55%,28%)] text-white"
          style={{ fontFamily: "'Montserrat', sans-serif" }}
        >
          Refazer Quiz
        </Button>
      </Card>
    );
  }

  return (
    <Card className="overflow-visible">
      <CardHeader className="flex flex-row items-center justify-between gap-2 pb-2">
        <div className="flex items-center gap-2">
          <HelpCircle className="w-5 h-5 text-[hsl(38,85%,55%)]" />
          <span className="text-sm font-medium text-muted-foreground" style={{ fontFamily: "'Montserrat', sans-serif" }}>
            Questão {currentQ + 1} de {questions.length}
          </span>
        </div>
        <Badge variant="outline" className="text-xs">
          Pontos: {score}
        </Badge>
      </CardHeader>
      <CardContent className="space-y-4">
        <h4
          className="text-lg font-semibold leading-snug"
          style={{ fontFamily: "'Playfair Display', serif" }}
          data-testid={`text-question-${currentQ}`}
        >
          {question.question}
        </h4>

        <div className="space-y-2">
          {(question.options || []).map((option, i) => {
            let optionClass = "border-border hover-elevate";
            if (showResult && i === question.correctIndex) {
              optionClass = "border-green-500 bg-green-50 dark:bg-green-900/20";
            } else if (showResult && i === selected && i !== question.correctIndex) {
              optionClass = "border-red-500 bg-red-50 dark:bg-red-900/20";
            }

            return (
              <button
                key={i}
                data-testid={`button-option-${i}`}
                onClick={() => handleAnswer(i)}
                disabled={selected !== null}
                className={`w-full text-left p-3 rounded-md border transition-all duration-200 flex items-center gap-3 ${optionClass} ${selected !== null ? "cursor-default" : "cursor-pointer"}`}
                style={{ fontFamily: "'Lora', serif" }}
              >
                <span className="w-7 h-7 rounded-full border flex-shrink-0 flex items-center justify-center text-xs font-semibold" style={{ fontFamily: "'Montserrat', sans-serif" }}>
                  {String.fromCharCode(65 + i)}
                </span>
                <span className="text-sm">{option}</span>
                {showResult && i === question.correctIndex && (
                  <CheckCircle2 className="w-5 h-5 text-green-600 dark:text-green-400 ml-auto flex-shrink-0" />
                )}
                {showResult && i === selected && i !== question.correctIndex && (
                  <XCircle className="w-5 h-5 text-red-600 dark:text-red-400 ml-auto flex-shrink-0" />
                )}
              </button>
            );
          })}
        </div>

        {showResult && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="p-3 rounded-md bg-[hsl(220,55%,28%)]/5 dark:bg-[hsl(220,55%,45%)]/10 border border-[hsl(220,55%,28%)]/10 dark:border-[hsl(220,55%,45%)]/20"
          >
            <p className="text-sm text-muted-foreground" style={{ fontFamily: "'Lora', serif" }}>
              <span className="font-semibold text-foreground">Explicação:</span> {question.explanation}
            </p>
          </motion.div>
        )}

        {showResult && (
          <div className="flex justify-end">
            <Button
              data-testid="button-next-question"
              onClick={nextQuestion}
              className="bg-[hsl(38,85%,55%)] text-[hsl(220,55%,12%)]"
              style={{ fontFamily: "'Montserrat', sans-serif" }}
            >
              {currentQ + 1 >= questions.length ? "Ver Resultado" : "Próxima"}
              <ArrowRight className="w-4 h-4 ml-1" />
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

export default function Home() {
  const { data: tales = [], isLoading: talesLoading } = useQuery<FairyTale[]>({
    queryKey: ["/api/tales"],
  });

  const { data: questions = [], isLoading: quizLoading } = useQuery<QuizQuestion[]>({
    queryKey: ["/api/quiz"],
  });

  return (
    <div className="min-h-screen bg-background">
      <nav className="sticky top-0 z-50 bg-[hsl(220,55%,18%)] border-b border-white/10 backdrop-blur-md">
        <div className="max-w-6xl mx-auto px-4 flex items-center justify-between h-14">
          <div className="flex items-center gap-2">
            <Scale className="w-5 h-5 text-[hsl(38,85%,65%)]" />
            <span className="font-bold text-white text-lg" style={{ fontFamily: "'Playfair Display', serif" }}>
              <span className="text-[hsl(38,85%,65%)]">LEX</span>FÁBULA
            </span>
          </div>
          <div className="hidden md:flex items-center gap-1" style={{ fontFamily: "'Montserrat', sans-serif" }}>
            {[
              { label: "Início", href: "#inicio" },
              { label: "Contos", href: "#contos" },
              { label: "Quiz", href: "#quiz" },
              { label: "Sobre", href: "#sobre" },
            ].map((item) => (
              <a
                key={item.href}
                href={item.href}
                data-testid={`link-nav-${item.label.toLowerCase()}`}
                className="px-3 py-1.5 text-sm text-white/70 rounded-md transition-colors duration-200 hover:text-white hover:bg-white/10"
              >
                {item.label}
              </a>
            ))}
          </div>
          <Badge className="bg-[hsl(38,85%,55%)]/20 text-[hsl(38,85%,65%)] border border-[hsl(38,85%,55%)]/30 no-default-hover-elevate no-default-active-elevate text-xs">
            <GraduationCap className="w-3 h-3 mr-1" />
            Faculdade Liber
          </Badge>
        </div>
      </nav>

      <div id="inicio">
        <HeroSection />
      </div>

      <section id="contos" className="max-w-6xl mx-auto px-4 py-16">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <Badge className="mb-4 bg-[hsl(220,55%,28%)]/10 text-[hsl(220,55%,28%)] dark:bg-[hsl(220,55%,45%)]/10 dark:text-[hsl(220,55%,65%)] border border-[hsl(220,55%,28%)]/20 dark:border-[hsl(220,55%,45%)]/20 no-default-hover-elevate no-default-active-elevate">
            <BookOpen className="w-3 h-3 mr-1" />
            Análise Jurídica
          </Badge>
          <h2
            className="text-3xl md:text-4xl font-bold mb-3"
            style={{ fontFamily: "'Playfair Display', serif" }}
          >
            Contos sob a Ótica do <span className="text-[hsl(38,85%,55%)]">Código Penal</span>
          </h2>
          <p
            className="text-muted-foreground max-w-xl mx-auto"
            style={{ fontFamily: "'Lora', serif" }}
          >
            Descubra como os personagens dos contos clássicos podem ser analisados
            a luz do Código Penal Brasileiro.
          </p>
        </motion.div>

        {talesLoading ? (
          <div className="space-y-6">
            {[1, 2, 3].map((i) => (
              <Card key={i} className="p-6 animate-pulse">
                <div className="flex flex-col lg:flex-row gap-4">
                  <div className="w-48 h-48 bg-muted rounded-md" />
                  <div className="flex-1 space-y-3">
                    <div className="h-6 bg-muted rounded-md w-1/3" />
                    <div className="h-4 bg-muted rounded-md w-2/3" />
                    <div className="h-4 bg-muted rounded-md w-1/2" />
                  </div>
                </div>
              </Card>
            ))}
          </div>
        ) : (
          <div className="space-y-6">
            {tales.map((tale, index) => (
              <TaleCard key={tale.id} tale={tale} index={index} />
            ))}
          </div>
        )}
      </section>

      <section id="quiz" className="bg-muted/30 py-16">
        <div className="max-w-3xl mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-10"
          >
            <Badge className="mb-4 bg-[hsl(38,85%,55%)]/10 text-[hsl(38,85%,40%)] dark:text-[hsl(38,85%,65%)] border border-[hsl(38,85%,55%)]/20 no-default-hover-elevate no-default-active-elevate">
              <Gavel className="w-3 h-3 mr-1" />
              Teste seus Conhecimentos
            </Badge>
            <h2
              className="text-3xl md:text-4xl font-bold mb-3"
              style={{ fontFamily: "'Playfair Display', serif" }}
            >
              Quiz <span className="text-[hsl(38,85%,55%)]">Jurídico</span>
            </h2>
            <p
              className="text-muted-foreground max-w-xl mx-auto"
              style={{ fontFamily: "'Lora', serif" }}
            >
              Teste seu conhecimento sobre os crimes identificados nos contos de fadas.
            </p>
          </motion.div>

          {quizLoading ? (
            <Card className="p-6 animate-pulse">
              <div className="space-y-3">
                <div className="h-6 bg-muted rounded-md w-2/3" />
                <div className="h-12 bg-muted rounded-md" />
                <div className="h-12 bg-muted rounded-md" />
                <div className="h-12 bg-muted rounded-md" />
              </div>
            </Card>
          ) : (
            <QuizSection questions={questions} />
          )}
        </div>
      </section>

      <section id="sobre" className="max-w-6xl mx-auto px-4 py-16">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-10"
        >
          <h2
            className="text-3xl md:text-4xl font-bold mb-3"
            style={{ fontFamily: "'Playfair Display', serif" }}
          >
            Sobre o <span className="text-[hsl(38,85%,55%)]">DICONT</span>
          </h2>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[
            {
              icon: GraduationCap,
              title: "Grupo de Estudos",
              desc: "O DICONT - Direito, Imaginário e Contos é um grupo de pesquisa acadêmica da Faculdade Liber em Porangatu-GO, coordenado pelo Professor Sandro Dias.",
            },
            {
              icon: Scale,
              title: "Proposta Acadêmica",
              desc: "Dedicado ao estudo interdisciplinar entre o Direito Penal, a Criminologia e a Literatura Infantojuvenil.",
            },
            {
              icon: Users,
              title: "Objetivo",
              desc: "Desconstruir a 'Justiça dos Contos' para entender como conceitos penais sao apresentados e moldam a percepção social.",
            },
          ].map((item, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
            >
              <Card className="h-full p-4">
                <div className="p-3 rounded-md bg-[hsl(220,55%,28%)]/10 dark:bg-[hsl(220,55%,45%)]/10 inline-flex mb-3">
                  <item.icon className="w-6 h-6 text-[hsl(220,55%,28%)] dark:text-[hsl(220,55%,65%)]" />
                </div>
                <h3 className="font-bold text-lg mb-2" style={{ fontFamily: "'Playfair Display', serif" }}>
                  {item.title}
                </h3>
                <p className="text-sm text-muted-foreground" style={{ fontFamily: "'Lora', serif" }}>
                  {item.desc}
                </p>
              </Card>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mt-10"
        >
          <Card className="p-6">
            <h3
              className="text-xl font-bold mb-4 flex items-center gap-2"
              style={{ fontFamily: "'Playfair Display', serif" }}
            >
              <Sparkles className="w-5 h-5 text-[hsl(38,85%,55%)]" />
              Áreas de Estudo
            </h3>
            <Accordion type="single" collapsible>
              {[
                {
                  title: "Direito Penal e Contos de Fadas",
                  content: "Análise das condutas típicas presentes nos contos clássicos, identificando crimes previstos no Código Penal Brasileiro como homicídio, maus-tratos, cárcere privado, estelionato e outros tipos penais.",
                },
                {
                  title: "Criminologia e Literatura",
                  content: "Estudo de como a literatura infantojuvenil apresenta conceitos criminológicos como culpa, retribuição, dolo e legítima defesa, e como essas narrativas influenciam a percepção social do sistema penal.",
                },
                {
                  title: "Justiça Restaurativa nos Contos",
                  content: "Reflexão sobre modelos alternativos de justiça presentes nos contos, questionando se a 'justiça dos contos' e compatível com os princípios modernos do Direito Penal brasileiro.",
                },
              ].map((item, i) => (
                <AccordionItem key={i} value={`item-${i}`}>
                  <AccordionTrigger
                    className="text-left"
                    style={{ fontFamily: "'Montserrat', sans-serif" }}
                    data-testid={`accordion-area-${i}`}
                  >
                    {item.title}
                  </AccordionTrigger>
                  <AccordionContent>
                    <p className="text-sm text-muted-foreground" style={{ fontFamily: "'Lora', serif" }}>
                      {item.content}
                    </p>
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </Card>
        </motion.div>
      </section>

      <footer className="bg-[hsl(220,55%,18%)] text-white py-10 border-t border-white/10">
        <div className="max-w-6xl mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <Scale className="w-5 h-5 text-[hsl(38,85%,65%)]" />
              <span className="font-bold text-lg" style={{ fontFamily: "'Playfair Display', serif" }}>
                <span className="text-[hsl(38,85%,65%)]">LEX</span>FÁBULA
              </span>
            </div>
            <p className="text-sm text-white/50 text-center" style={{ fontFamily: "'Lora', serif" }}>
              DICONT - Direito, Imaginário e Contos | Faculdade Liber - Porangatu/GO
            </p>
            <p className="text-xs text-white/40 text-center" style={{ fontFamily: "'Montserrat', sans-serif" }}>
              Gestor Professor Sandro Dias
            </p>
            <div className="flex items-center gap-2">
              <Badge className="bg-white/10 text-white/70 no-default-hover-elevate no-default-active-elevate text-xs">
                Direito Penal
              </Badge>
              <Badge className="bg-white/10 text-white/70 no-default-hover-elevate no-default-active-elevate text-xs">
                Criminologia
              </Badge>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
