import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  app.get("/api/tales", async (_req, res) => {
    const tales = await storage.getAllTales();
    res.json(tales);
  });

  app.get("/api/tales/:slug", async (req, res) => {
    const tale = await storage.getTaleBySlug(req.params.slug);
    if (!tale) {
      return res.status(404).json({ message: "Tale not found" });
    }
    res.json(tale);
  });

  app.get("/api/quiz", async (_req, res) => {
    const questions = await storage.getAllQuizQuestions();
    res.json(questions);
  });

  return httpServer;
}
