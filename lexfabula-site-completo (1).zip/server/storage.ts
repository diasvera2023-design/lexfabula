import { type User, type InsertUser, type FairyTale, type InsertFairyTale, type QuizQuestion, type InsertQuizQuestion, users, fairyTales, quizQuestions } from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getAllTales(): Promise<FairyTale[]>;
  getTaleBySlug(slug: string): Promise<FairyTale | undefined>;
  createTale(tale: InsertFairyTale): Promise<FairyTale>;
  getAllQuizQuestions(): Promise<QuizQuestion[]>;
  getQuizQuestionsByTaleId(taleId: number): Promise<QuizQuestion[]>;
  createQuizQuestion(question: InsertQuizQuestion): Promise<QuizQuestion>;
  getTalesCount(): Promise<number>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values({ ...insertUser, id: randomUUID() }).returning();
    return user;
  }

  async getAllTales(): Promise<FairyTale[]> {
    return db.select().from(fairyTales).orderBy(fairyTales.order);
  }

  async getTaleBySlug(slug: string): Promise<FairyTale | undefined> {
    const [tale] = await db.select().from(fairyTales).where(eq(fairyTales.slug, slug));
    return tale;
  }

  async createTale(tale: InsertFairyTale): Promise<FairyTale> {
    const [created] = await db.insert(fairyTales).values(tale).returning();
    return created;
  }

  async getAllQuizQuestions(): Promise<QuizQuestion[]> {
    return db.select().from(quizQuestions);
  }

  async getQuizQuestionsByTaleId(taleId: number): Promise<QuizQuestion[]> {
    return db.select().from(quizQuestions).where(eq(quizQuestions.taleId, taleId));
  }

  async createQuizQuestion(question: InsertQuizQuestion): Promise<QuizQuestion> {
    const [created] = await db.insert(quizQuestions).values(question).returning();
    return created;
  }

  async getTalesCount(): Promise<number> {
    const result = await db.select().from(fairyTales);
    return result.length;
  }
}

export const storage = new DatabaseStorage();
