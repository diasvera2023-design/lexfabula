import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, serial, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const fairyTales = pgTable("fairy_tales", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  slug: text("slug").notNull().unique(),
  summary: text("summary").notNull(),
  imageUrl: text("image_url"),
  content: text("content").notNull(),
  crimes: text("crimes").array().notNull(),
  articles: text("articles").array().notNull(),
  penalties: text("penalties").array().notNull(),
  tipificacao: text("tipificacao").array(),
  jurisprudencia: text("jurisprudencia").array(),
  fundamentacao: text("fundamentacao").array(),
  order: integer("order").notNull().default(0),
});

export const quizQuestions = pgTable("quiz_questions", {
  id: serial("id").primaryKey(),
  taleId: integer("tale_id").notNull(),
  question: text("question").notNull(),
  options: text("options").array().notNull(),
  correctIndex: integer("correct_index").notNull(),
  explanation: text("explanation").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertFairyTaleSchema = createInsertSchema(fairyTales).omit({
  id: true,
});

export const insertQuizQuestionSchema = createInsertSchema(quizQuestions).omit({
  id: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type FairyTale = typeof fairyTales.$inferSelect;
export type InsertFairyTale = z.infer<typeof insertFairyTaleSchema>;
export type QuizQuestion = typeof quizQuestions.$inferSelect;
export type InsertQuizQuestion = z.infer<typeof insertQuizQuestionSchema>;
